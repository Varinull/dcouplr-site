#!/usr/bin/env bash
# ==============================================================================
# <dcouplr/> Turnkey Air-Gapped Offline Installer v1.0.0
# Organization: varinull | Repository: dcouplr
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=== [1/4] Verifying SHA-256 Cryptographic Checksums ==="
if command -v sha256sum &>/dev/null; then
    sha256sum -c SHA256SUMS
elif command -v shasum &>/dev/null; then
    shasum -a 256 -c SHA256SUMS
else
    echo "[WARN] No sha256sum utility found. Skipping checksum verification."
fi

echo "=== [2/4] Loading Container Images into Local Daemon ==="
if [ -d "images" ]; then
    for img_tar in images/*.tar; do
        if [ -f "$img_tar" ]; then
            echo "Loading $img_tar..."
            docker load -i "$img_tar" || ctr images import "$img_tar" || true
        fi
    done
fi

echo "=== [3/4] Installing Kubernetes Custom Resource Definitions ==="
if command -v kubectl &>/dev/null; then
    kubectl apply -f crds/synccontroller-crd.yaml
    kubectl apply -f manifests/network-policy.yaml
fi

echo "=== [4/4] Deploying Production Helm Chart ==="
if command -v helm &>/dev/null; then
    helm upgrade --install dcouplr charts/dcouplr \
        --namespace kube-system \
        --set image.repository="ghcr.io/varinull/dcouplr" \
        --set image.tag="v1.0.0" \
        --set operator.image.repository="ghcr.io/varinull/dcouplr-operator" \
        --set operator.image.tag="v1.0.0"
fi

echo "=============================================================================="
echo " [SUCCESS] Air-Gapped Installation of dcouplr v1.0.0 Complete!"
echo "=============================================================================="
