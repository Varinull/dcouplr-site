# <dcouplr/> Offline Air-Gapped Deployment Bundle
**Version:** v1.0.0  
**Organization:** `varinull`  
**Repository:** `https://github.com/varinull/dcouplr`  

## Contents
1. `charts/dcouplr/`: Production Helm chart.
2. `crds/`: Kubernetes CustomResourceDefinitions (`SyncController`).
3. `images/`: Offline container image tarballs and `manifest.json`.
4. `sbom/`: CycloneDX 1.5 (`sbom-cyclonedx.json`) and SPDX 2.3 (`sbom-spdx.json`).
5. `provenance/`: SLSA Level 3 In-toto provenance attestation (`slsa-provenance.json`).
6. `security/`: Cosign public key (`cosign.pub`) and signature (`cosign.sig`).
7. `install.sh`: Turnkey automated offline installation script.
8. `verify.sh`: Offline cryptographic signature and SHA-256 validation script.
9. `SHA256SUMS`: Pre-computed cryptographic checksums.

## Installation
```bash
./verify.sh
./install.sh
```
